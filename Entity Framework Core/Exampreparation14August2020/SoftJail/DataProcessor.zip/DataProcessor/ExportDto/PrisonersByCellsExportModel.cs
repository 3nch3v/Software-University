﻿namespace SoftJail.DataProcessor.ExportDto
{
    using System.Collections.Generic;

    public class PrisonersByCellsExportModel
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public int CellNumber { get; set; }

        public ICollection<OfficerExportModel> Officers { get; set; }

        public decimal TotalOfficerSalary { get; set; }
    }

    public class OfficerExportModel
    {
        public string OfficerName { get; set; }

        public string Department { get; set; }

    }
}

