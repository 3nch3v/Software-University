﻿namespace SoftJail
{
    using AutoMapper;

    public class SoftJailProfile : Profile
    {
        public SoftJailProfile()
        {

        }
    }
}
