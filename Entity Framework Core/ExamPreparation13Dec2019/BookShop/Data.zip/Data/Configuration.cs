﻿namespace BookShop.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-PFRD5K8\SQLEXPRESS;Database=BookShop;Trusted_Connection=True";
    }
}