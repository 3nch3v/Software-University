﻿
namespace BorderControl
{
    public interface IPersonable
    { 
        string Name { get; set; }
        string Birthdate { get; set; }
    }
}
