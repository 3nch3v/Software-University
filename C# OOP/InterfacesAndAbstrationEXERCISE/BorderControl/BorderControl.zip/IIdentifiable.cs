﻿
namespace BorderControl
{
    public interface IIdentifiable
    {
        string Id { get; set; }

    }
}
