﻿using System;
using System.Collections.Generic;
using System.Reflection.Metadata;
using System.Text;

namespace Cars
{
    public interface IElectricCar
    {
        public int Battery { get; set; }

    }
}
