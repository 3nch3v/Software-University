﻿using System;
using System.Collections.Generic;

namespace CustomRandomList
{
    public class StartUp
    {
        static void Main(string[] args)
        {
           List<string> list = new List<string>();

           list.Add("da");
           list.Add("ne");
           list.Add("ko");
           list.Add("koga");
           list.Add("moje");
           list.Add("upsurd");

           RandomList randomList = new RandomList(list);

           Console.WriteLine(randomList.RandomString());
           Console.WriteLine(randomList.RandomString());
           Console.WriteLine(randomList.RandomString());
           Console.WriteLine(randomList.RandomString());
        }
    }
}
