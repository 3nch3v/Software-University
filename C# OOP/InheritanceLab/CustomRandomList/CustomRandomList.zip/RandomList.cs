﻿
using System;
using System.Collections.Generic;

namespace CustomRandomList
{
    public class RandomList : List<string>
    {
        private Random random;
        public RandomList(List<string> list)
        {
            Data = new List<string>(list);   
            random = new Random();
        }

        public List<string> Data { get; set; }


        public string RandomString()
        {
            string randomElment = Data[random.Next(0, Data.Count)];

            return randomElment;
        }

    }
}
