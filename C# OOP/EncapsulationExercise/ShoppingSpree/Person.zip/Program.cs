﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ShoppingSpree
{
    public class Program
    {
        static void Main(string[] args)
        {
            try
            {
                List<Person> persons = new List<Person>();
                var clientsData = Console.ReadLine().Split(";", StringSplitOptions.RemoveEmptyEntries);

                foreach (var client in clientsData)
                {
                    var currClientArgs = client.Split('=', StringSplitOptions.RemoveEmptyEntries);
                    string name = currClientArgs[0];
                    decimal money = decimal.Parse(currClientArgs[1]);

                    Person newPerson = new Person(name, money);
                    persons.Add(newPerson);
                }

                List<Product> products = new List<Product>();
                var productsInfo = Console.ReadLine().Split(";", StringSplitOptions.RemoveEmptyEntries);

                foreach (var product in productsInfo)
                {
                    var currProductInfo = product.Split('=', StringSplitOptions.RemoveEmptyEntries);
                    string name = currProductInfo[0];
                    decimal money = decimal.Parse(currProductInfo[1]);

                    Product newProduct = new Product(name, money);
                    products.Add(newProduct);
                }

                string comand;

                while ((comand = Console.ReadLine()) != "END")
                {
                    var currPerson = comand.Split(" ", StringSplitOptions.RemoveEmptyEntries);
                    string name = currPerson[0];
                    string product = currPerson[1];

                    Person currClient = persons.FirstOrDefault(c => c.Name == name);
                    Product currProduct = products.FirstOrDefault(p => p.Name == product);
                    currClient.BuyProduct(currProduct);
                }

                foreach (var person in persons)
                {
                    if (person.Bag.Count > 0)
                    {
                        Console.WriteLine($"{person.Name} - {string.Join(", ", person.Bag)}");
                    }

                    else
                    {
                        Console.WriteLine($"{person.Name} - Nothing bought");
                    }
                }
            }
            catch (ArgumentException e)
            {
                Console.WriteLine(e.Message);
                return;
            }
        }
    }
}
