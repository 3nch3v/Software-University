﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {  //1. Define a Class Person

            //Person firstPerson = new Person();
            //firstPerson.Name = "Pesho";
            //firstPerson.Age = 20;

            //Person secondPerson = new Person();
            //secondPerson.Name = "Gosho";
            //secondPerson.Age = 18;

            //Person thirdPerson = new Person();
            //thirdPerson.Name = "Stamat";
            //thirdPerson.Age = 43;


            //2. Creating Constructors

            //Person firstPerson = new Person();

            //Person secondPerson = new Person(18);

            //Person thirdPerson = new Person("Pesho", 22);


            // 3. Oldest Family Member

            Family familyMembers = new Family();

            int personsCount = int.Parse(Console.ReadLine());

            for (int i = 0; i < personsCount; i++)
            {
                string[] personData = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries);
                string name = personData[0];
                int age = int.Parse(personData[1]);

                Person currPerson = new Person(name, age);

                familyMembers.AddMember(currPerson);
            }

            Person theOldestOne = familyMembers.GetOldestMember();
            Console.WriteLine($"{theOldestOne.Name} {theOldestOne.Age}");
        }
    }
}
