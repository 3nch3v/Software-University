﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {  //1. Define a Class Person

            //Person firstPerson = new Person();
            //firstPerson.Name = "Pesho";
            //firstPerson.Age = 20;

            //Person secondPerson = new Person();
            //secondPerson.Name = "Gosho";
            //secondPerson.Age = 18;

            //Person thirdPerson = new Person();
            //thirdPerson.Name = "Stamat";
            //thirdPerson.Age = 43;

            //2. Creating Constructors

            Person firstPerson = new Person();
          
            Person secondPerson = new Person(18);
         
            Person thirdPerson = new Person("Pesho", 22);
  

        }
    }
}
